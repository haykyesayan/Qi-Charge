package com.example.qipowerbank;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class NotificationsFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final ArrayList<ExampleItem> exampleList=new ArrayList<>();
        exampleList.add(new ExampleItem(R.drawable.ic_android, "Line 1", "Line 2"));
        exampleList.add(new ExampleItem(R.drawable.ic_android, "Line 3", "Line 4"));

        View rootView=inflater.inflate(R.layout.fragment_notifications, null);

        mRecyclerView=(RecyclerView)rootView.findViewById(R.id.recyclerView);
        /**
        mRecyclerView = mRecyclerView.findViewById(R.id.recyclerView);
         */
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager=new LinearLayoutManager(this.getActivity());
        mAdapter=new ExampleAdapter(exampleList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                exampleList.get(position).changeText1("Clicked");
                mAdapter.notifyItemChanged(position);
            }
        });
        return rootView;
    }

}
